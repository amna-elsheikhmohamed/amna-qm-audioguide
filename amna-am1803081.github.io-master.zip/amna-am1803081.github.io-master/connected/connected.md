---
layout: connected
permalink: /connected/
type:
title: WiFi Connected
---

You have successfully connected to the WiFi.

<a href="../welcome/" target="_system">Launch Audio Guide</a>